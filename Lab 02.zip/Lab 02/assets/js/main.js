function toggleTheme() {
    var declaration = document.getElementsByTagName('html')[0];
    if (getComputedStyle(document.body).getPropertyValue('--body-color') == "white") {    
        declaration.style.setProperty("--body-color", "blue");
        declaration.style.setProperty("--navbar-bg-color", "rgb(41, 172, 248)");
        declaration.style.setProperty("--background-color", "rgb(122, 227, 255)");
        declaration.style.setProperty("--section-text-color", "white");
    } else {      
        declaration.style.setProperty("--body-color", "white");
        declaration.style.setProperty("--navbar-bg-color", "rgb(122, 227, 255)");
        declaration.style.setProperty("--background-color", "blue");
        declaration.style.setProperty("--section-text-color", "black");
    }
}
