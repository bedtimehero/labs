﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace Lab06.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new Lab06Context(
                serviceProvider.GetRequiredService<DbContextOptions<Lab06Context>>()))
            {
                // Look for any movies.
                if (context.Movie.Any())
                {
                    return;   // DB has been seeded
                }

                context.Movie.AddRange(
                     new Movie
                     {
                         Title = "Black Panther",
                         ReleaseDate = DateTime.Parse("2018-2-16"),
                         Genre = "Fantasy",
                         Rating = "PG13",
                         Price = 8.99M,
                         PosterURL = ""
                     }
                );
                context.SaveChanges();
            }
        }
    }
}